<?php
include "inc/MySQL/mySQLFunc.php";
echo delPoll($_POST['pollID']);
?>