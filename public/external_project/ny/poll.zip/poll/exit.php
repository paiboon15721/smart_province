<?php
session_start();
session_destroy();
?>
<script language="javascript" src="inc/js/jsFunc.js"></script>
<script type="text/javascript">
closeWin();
</script>